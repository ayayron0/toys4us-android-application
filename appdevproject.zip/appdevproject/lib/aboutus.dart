import 'package:flutter/material.dart';

class AboutUsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        "About Us Page",
        style: TextStyle(fontSize: 22),),
    );
  }
}