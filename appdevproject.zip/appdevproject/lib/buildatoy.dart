import 'package:flutter/material.dart';

class BuildAToyPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        "Build-A-Toy Page",
        style: TextStyle(fontSize: 22),
      ),
    );
  }
}