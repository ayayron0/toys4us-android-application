package com.example.buildaplushtoystore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
